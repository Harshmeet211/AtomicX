export function bookAppointment(slot) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          token: Math.floor(100 + Math.random() * 900),
          time: slot.time,
          doctor: slot.doctor || "Dr. Smith",
        });
      }, 800);
    });
  }
  
  export function getHistory() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          { id: 1, date: "2025-04-01", doctor: "Dr. Verma", status: "Completed" },
          { id: 2, date: "2025-04-25", doctor: "Dr. Nisha", status: "Upcoming" },
        ]);
      }, 600);
    });
  }
  