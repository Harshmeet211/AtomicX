export function uploadReport(file) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ status: "ok", filename: file.name });
      }, 1000);
    });
  }
  