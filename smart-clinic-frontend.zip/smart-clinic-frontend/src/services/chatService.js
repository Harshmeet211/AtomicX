let chatLog = [];

export function sendMessage(text) {
  return new Promise((resolve) => {
    const message = { id: Date.now(), text };
    chatLog.push(message);
    setTimeout(() => resolve(message), 300);
  });
}

export function getMessages() {
  return new Promise((resolve) => {
    setTimeout(() => resolve([...chatLog]), 300);
  });
}
