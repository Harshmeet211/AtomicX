import { Link, Outlet, useNavigate } from "react-router-dom";
import { useContext } from "react";
import { UserContext } from "../components/UserContext";

export default function Layout() {
  const { user, logout } = useContext(UserContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div>
      <nav className="bg-blue-600 text-white p-4 flex justify-between items-center">
        <div className="space-x-4">
          <Link to="/" className="font-bold text-xl">SmartClinic</Link>
          {user?.role === "patient" && <Link to="/patient" className="hover:underline">Patient Dashboard</Link>}
          {user?.role === "doctor" && <Link to="/doctor" className="hover:underline">Doctor Dashboard</Link>}
        </div>
        <div>
          {user ? (
            <>
              <span className="mr-4">Logged in as <strong>{user.role}</strong></span>
              <button onClick={handleLogout} className="bg-red-500 px-3 py-1 rounded text-white">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="mr-4">Login</Link>
              <Link to="/signup">Signup</Link>
            </>
          )}
        </div>
      </nav>
      <main className="p-4">
        <Outlet />
      </main>
    </div>
  );
}
