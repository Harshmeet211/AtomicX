import { useContext, useEffect, useState } from "react";
import { UserContext } from "../components/UserContext";
import { useNavigate } from "react-router-dom";
import { bookAppointment, getHistory } from "../services/appointmentService";
import QRCode from "react-qr-code";

const PatientDashboard = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  const [history, setHistory] = useState([]);
  const [booking, setBooking] = useState(null);

  useEffect(() => {
    if (!user || user.role !== "patient") {
      navigate("/login");
    } else {
      getHistory().then(setHistory);
    }
  }, [user, navigate]);

  const handleBook = () => {
    const dummySlot = { time: "10:30 AM", doctor: "Dr. Gupta" };
    bookAppointment(dummySlot).then((res) => setBooking(res));
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Welcome to the Patient Dashboard</h1>
      <p className="mb-4">Logged in as: {user?.email}</p>

      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Book Appointment</h2>
        <button onClick={handleBook} className="bg-green-600 text-white px-4 py-2 rounded">
          Book Dummy Appointment
        </button>
        {booking && (
          <div className="mt-4 p-3 border rounded bg-gray-100">
            <p className="font-medium">Booking Confirmed!</p>
            <p>Doctor: {booking.doctor}</p>
            <p>Time: {booking.time}</p>
            <p className="mt-2">Token: <strong>{booking.token}</strong></p>
            <div className="mt-4">
              <QRCode value={booking.token.toString()} size={128} />
            </div>
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-2">Appointment History</h2>
        <ul className="list-disc pl-5">
          {history.map((h) => (
            <li key={h.id}>{h.date} – {h.doctor} ({h.status})</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default PatientDashboard;
