import { useContext, useEffect, useState } from "react";
import { UserContext } from "../components/UserContext";
import { useNavigate } from "react-router-dom";
import { uploadReport } from "../services/reportService";
import { sendMessage, getMessages } from "../services/chatService";

const DoctorDashboard = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  const [tokens, setTokens] = useState([101, 102]);
  const [reportFile, setReportFile] = useState(null);
  const [chatLog, setChatLog] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!user || user.role !== "doctor") {
      navigate("/login");
    }

    const interval = setInterval(() => {
      setTokens((prev) => [...prev, prev[prev.length - 1] + 1]);
    }, 15000);

    return () => clearInterval(interval);
  }, [user, navigate]);

  useEffect(() => {
    getMessages().then(setChatLog);
  }, []);

  const handleUpload = () => {
    if (reportFile) {
      uploadReport(reportFile).then((res) => {
        alert("Uploaded: " + res.filename);
        setReportFile(null);
      });
    }
  };

  const handleSend = () => {
    if (msg.trim()) {
      sendMessage(msg).then((newMsg) => {
        setChatLog((prev) => [...prev, newMsg]);
        setMsg("");
      });
    }
  };

  return (
    <div className="grid md:grid-cols-3 gap-6 p-6">
      <div className="p-4 border rounded shadow">
        <h2 className="text-xl font-semibold mb-3">Live Token Queue</h2>
        <ul className="space-y-2">
          {tokens.map((t) => (
            <li key={t} className="bg-gray-100 px-3 py-1 rounded">Token #{t}</li>
          ))}
        </ul>
      </div>

      <div className="p-4 border rounded shadow">
        <h2 className="text-xl font-semibold mb-3">Upload Patient Report</h2>
        <input type="file" onChange={(e) => setReportFile(e.target.files[0])} className="mb-2" />
        <button onClick={handleUpload} className="bg-green-600 text-white px-4 py-2 rounded w-full">
          Upload
        </button>
      </div>

      <div className="p-4 border rounded shadow col-span-1">
        <h2 className="text-xl font-semibold mb-3">Doctor Chat</h2>
        <div className="h-40 overflow-y-auto border p-2 mb-2 bg-gray-50">
          {chatLog.map((c) => (
            <div key={c.id} className="mb-1">{c.text}</div>
          ))}
        </div>
        <input
          value={msg}
          onChange={(e) => setMsg(e.target.value)}
          className="border p-2 rounded w-full mb-2"
          placeholder="Type a message..."
        />
        <button onClick={handleSend} className="bg-blue-600 text-white px-4 py-1 rounded w-full">
          Send
        </button>
      </div>
    </div>
  );
};

export default DoctorDashboard;
